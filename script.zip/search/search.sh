#!/bin/bash

DUMP="/var/mobile/dylib3/dump.cs"
SCRIPT="/var/mobile/dylib3/script.json"
OUT="/var/mobile/dylib3/rva_result.txt"

{
    echo "=========================================="
    echo "空洞骑士 关键 RVA 提取"
    echo "时间: $(date)"
    echo "=========================================="
    echo ""

    # ========== 1. HeroController.TakeDamage ==========
    echo "[1] HeroController.TakeDamage"
    echo "--- dump.cs ---"
    grep -A 3 "HeroController.*TakeDamage" "$DUMP" 2>/dev/null | grep "RVA:" | head -5
    echo "--- script.json ---"
    grep -i "HeroController.*TakeDamage" "$SCRIPT" 2>/dev/null | head -3
    echo ""

    # ========== 2. HealthManager.Hit ==========
    echo "[2] HealthManager.Hit"
    echo "--- dump.cs ---"
    grep -A 3 "HealthManager.*Hit" "$DUMP" 2>/dev/null | grep "RVA:" | head -5
    echo "--- script.json ---"
    grep -i "HealthManager.*Hit" "$SCRIPT" 2>/dev/null | head -3
    echo ""

    # ========== 3. ShadowDash ==========
    echo "[3] ShadowDash"
    echo "--- dump.cs ---"
    grep -A 1 "ShadowDash\|void ShadowDash\|Shadow Dash" "$DUMP" 2>/dev/null | grep "RVA:" | head -5
    echo "--- script.json ---"
    grep -i "ShadowDash\|Shadow_Dash" "$SCRIPT" 2>/dev/null | head -3
    echo ""

    # ========== 4. tk2dSpriteAnimator.Play ==========
    echo "[4] tk2dSpriteAnimator.Play"
    echo "--- dump.cs ---"
    grep -A 1 "public void Play" "$DUMP" 2>/dev/null | grep "RVA:" | head -5
    echo "--- script.json ---"
    grep -i "tk2dSpriteAnimator.*Play\|Play.*tk2dSpriteAnimator" "$SCRIPT" 2>/dev/null | head -3
    echo ""

    # ========== 5. HealthManager.TakeDamage ==========
    echo "[5] HealthManager.TakeDamage"
    echo "--- dump.cs ---"
    grep -A 3 "HealthManager.*TakeDamage" "$DUMP" 2>/dev/null | grep "RVA:" | head -5
    echo "--- script.json ---"
    grep -i "HealthManager.*TakeDamage" "$SCRIPT" 2>/dev/null | head -3
    echo ""

    # ========== 6. BossSceneController ==========
    echo "[6] BossSceneController"
    echo "--- dump.cs ---"
    grep -A 3 "BossSceneController" "$DUMP" 2>/dev/null | grep "RVA:" | head -10
    echo "--- script.json ---"
    grep -i "BossSceneController" "$SCRIPT" 2>/dev/null | grep -i "health\|damage\|hit" | head -5
    echo ""

    # ========== 7. HeroController.ShadowDash 方法 ==========
    echo "[7] HeroController 中的 ShadowDash 方法"
    echo "--- dump.cs ---"
    grep -B 5 "ShadowDash\|hasShadowDash\|canShadowDash\|shadow.*dash" "$DUMP" 2>/dev/null | grep -E "RVA:|class HeroController" | head -20
    echo ""

    # ========== 8. 字段偏移确认 ==========
    echo "[8] 关键字段偏移"
    echo "--- dump.cs ---"
    grep -E "attack_cooldown|hasShadowDash|canShadowDash|hp //" "$DUMP" 2>/dev/null | head -10
    echo ""

    echo "=========================================="
    echo "提取完成"
    echo "=========================================="

} > "$OUT"

cat "$OUT"
echo ""
echo "结果已保存到: $OUT"